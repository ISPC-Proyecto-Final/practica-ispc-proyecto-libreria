package com.proyectoispc.libreria;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class feedbackErrorBuscador extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback_error_buscador);
    }
}