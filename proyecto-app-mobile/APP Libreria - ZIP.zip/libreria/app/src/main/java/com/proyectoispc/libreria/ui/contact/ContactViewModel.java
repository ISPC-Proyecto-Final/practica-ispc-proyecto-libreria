package com.proyectoispc.libreria.ui.contact;

import androidx.lifecycle.ViewModel;

public class ContactViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}